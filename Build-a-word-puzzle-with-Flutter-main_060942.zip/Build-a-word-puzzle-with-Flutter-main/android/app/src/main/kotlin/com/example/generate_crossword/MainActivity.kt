package com.example.generate_crossword

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
